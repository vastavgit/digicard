import logo from './logo.svg';
import './App.css';
import { Route } from 'wouter';
import FrstHead from './compoDir/frsthead';
import NavBar from './compoDir/navbar';
import About from './compoDir/about';
import FrstPara from './compoDir/frstpara';
import PFpic from './compoDir/pfpic';
import MRGNtxt from './compoDir/mrgntxt';
import NameHead from './compoDir/namehead';
import DescPara from './compoDir/descpara';
import ProPara from './compoDir/propara';
import BookHead from './compoDir/bookhead';
import BookPara from './compoDir/bookpara';
import AbtHead from './aboutComp/abthead';
import AbtPara from './aboutComp/abtpara';
import AbtImg from './aboutComp/abtimg';
import CntctPg from './contactComp/cntctpg';
import IDcard from './1pageComp/idcard';
import CopyText from './compoDir/copytext';

function App() {
  return (
    <div className="App">
      <main>
      <NavBar/>
      <Route path='/'>
      <FrstHead/>
      <FrstPara/>
      <MRGNtxt/>
      <PFpic/>
      <NameHead/>
      <ProPara/>
      <DescPara/>
      <BookHead/>
      <BookPara/>
      <CopyText/>
      </Route>
      <Route path='/about'>
      <AbtHead/>
      <MRGNtxt/>
      <AbtImg/>
      <MRGNtxt/>
      <AbtPara/>
      </Route>
      <Route path='/contact'>
        <CntctPg/>
      </Route>
      <Route path='/onepage'>
        <MRGNtxt/>
        <IDcard/>
      </Route>
      </main>
    </div>
  );
}

export default App;
