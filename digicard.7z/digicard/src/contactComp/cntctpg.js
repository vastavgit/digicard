import React from 'react'

export default function CntctPg() {
  return (
    <div>
      <h3 className='text-primary'>Official contact</h3>
      <p className='text-danger'>Email address : <a href='https://mail.google.com/mail/u/0/#inbox?compose=CllgCKCDBwCLXHmGwmhcMxJmjlCQZgcrDNHtlxsqFbkLTgxvRxLBBHLvcJpTGTGFxNfZmdXhgbq' className='text-success text-decoration-none'>vastavtechsol@gmail.com</a></p>
      <hr/>
      <h3 className='text-primary'>Socials</h3>
      <p className='text-danger'> Website : <a href='https://imvastav.netlify.app' className='text-decoration-none text-success'>Click here</a></p>
      <p className='text-danger'> Quora : <a href='https://www.quora.com/profile/Saptarshi-Paul-83' className='text-decoration-none text-success'>Click here</a></p>
      <p className='text-danger'> LinkedIn : <a href='https://www.linkedin.com/in/saptarshi-paul-128b87262/' className='text-decoration-none text-success'>Click here</a></p>
      <p className='text-danger'> Replit : <a href='https://replit.com/@vastavrepl' className='text-decoration-none text-success'>Click here</a></p>
      <p className='text-danger'> GitHub : <a href='https://github.com/vastavgit' className='text-decoration-none text-success'>Click here</a></p>
      <p className='text-danger'> Stack Overflow : <a href='https://stackoverflow.com/users/21503324/saptarshi-paul' className='text-decoration-none text-success'>Click here</a></p>
      <p className='text-danger'> Steam : <a href='https://steamcommunity.com/id/vastavsteam/' className='text-decoration-none text-success'>Click here</a></p>
      <p className='text-danger'> Upwork : <a href='https://www.upwork.com/freelancers/~017f4337524f65b0ce' className='text-decoration-none text-success'>Click here</a></p>
      <hr/>
    </div>
  )
}
