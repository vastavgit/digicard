import React from 'react'

export default function FrstPara() {
  return (
    <div>
      <p className='fs-5 fw-semibold text-decoration-none text-success-emphasis text-decoration-underline'>DigiCard is the name of the digital ID card. This card is owned by Saptarshi Paul aka "IM Vastav". He built it in React and did so because of a vulnerability of LINQAPP. This React app allowed him more freedom. You can navigate through different pages to view the card or view in 1 page</p>
    </div>
  )
}
