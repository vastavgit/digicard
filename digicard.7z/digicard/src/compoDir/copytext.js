import React from 'react'

export default function CopyText() {
  return (
    <div>
      <h6 className='text-danger'>Copyright &copy; DigiCard 2023 All Rights Reserved</h6>
    </div>
  )
}
