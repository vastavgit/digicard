import React from 'react'

export default function FrstHead() {
  return (
    <div>
      <h1 className='text-danger-emphasis fs-2 font-monospace'>Welcome to DigiCard</h1>
    </div>
  )
}
