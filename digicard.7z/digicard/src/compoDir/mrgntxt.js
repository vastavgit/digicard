import React from 'react'

export default function MRGNtxt() {
  return (
    <div>
      <p></p>
      <br/>
    </div>
  )
}
