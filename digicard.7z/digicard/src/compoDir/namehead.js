import React from 'react'

export default function NameHead() {
  return (
    <div>
      <h1 className='text-success'>Saptarshi Paul</h1>
    </div>
  )
}
