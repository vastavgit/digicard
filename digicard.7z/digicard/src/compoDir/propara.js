import React from 'react'

export default function ProPara() {
  return (
    <div>
      <h4 className='text-primary'>Software Developer from Kolkata, WB, India</h4>
    </div>
  )
}
