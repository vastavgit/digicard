import React from 'react'
// import "./styles.css";

export default function PFpic() {
  return (
    <div>
      <img src='/profile.jpg' alt='PFP'></img>
    </div>
  )
}
