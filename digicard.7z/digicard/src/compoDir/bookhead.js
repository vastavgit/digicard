import React from 'react'

export default function BookHead() {
  return (
    <div>
      <h3 className='text-warning bg-dark'>Book a consultancy with Saptarshi Paul right now</h3>
    </div>
  )
}
