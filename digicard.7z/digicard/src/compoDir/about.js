import React from 'react'

export default function About() {
  return (
    <div>
      <p class="text-success">Hi, you are in ABOUT territory rn</p>
    </div>
  )
}
