import React from 'react'

export default function BookPara() {
  return (
    <div>
      <p>To book a consultancy with Saptarshi Paul/Vastav, <a href='mailto:vastavtechsol@gmail.com' className='text-decoration-none'>click here</a></p>
    </div>
  )
}
