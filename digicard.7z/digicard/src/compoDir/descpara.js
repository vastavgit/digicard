import React from 'react'

export default function DescPara() {
  return (
    <div>
      <p className='text-danger'>Saptarshi Paul is a software developer from Kolkata, WB, India. He goes by the name "Vastav" online and is passionate towards coding. He's primarily a web developer, Android developer, React developer and Python developer and has a lot of skills in programming and even cybersecurity and he always learns according to market trends or his wish. He's a software developer at Upwork and uses it to find his clients though he uses LinkedIn and cold-mailing as well.</p>
    </div>
  )
}
