import React from 'react'

export default function IDcard() {
  return (
    <div>
      {/* <h1>If you see this, it works</h1> */}
      <img src='./profile.jpg' alt='PFP'></img>
      <br/><br/>
      <h3 className='text-primary-emphasis'>Saptarshi Paul</h3>
      {/* <br/> */}
      <h5 className='text-danger-emphasis'>Software Developer from Kolkata, WB, India</h5>
      <br/>
      <p className='text-info bg-dark'>Saptarshi Paul is a software developer from Kolkata, WB, India. He goes by the name "Vastav" online and is passionate towards coding. He's primarily a web developer, Android developer, React developer and Python developer and has a lot of skills in programming and even cybersecurity and he always learns according to market trends or his wish. He's a software developer at Upwork and uses it to find his clients though he uses LinkedIn and cold-mailing as well.</p>
      <br/>
      <p className='text-primary'>To book a consultancy with Saptarshi Paul, <a href='mailto:vastavtechsol@gmail.com' className='text-decoration-none text-success'>click here</a></p>
      <br/>
      <h3 className='text-success-emphasis'>Who is Saptarshi Paul?</h3>
      <p className='text-success'>Hi, I am Saptarshi Paul aka Vastav, an Indian software developer, hailing from the city of Kolkata, WB, India. I have always been passionate towards programming and at the age of 16, I managed to learn those basics which gave me a kickstart in coding. I'm a Web Developer, Android Developer, React Developer, Python Developer. I have quite a significant amount of skills in programming and cybersecurity too. While my family always criticised me for being a coder, I knew what was right for me and what was not. I'm a software developer at Upwork and use the platform to find my clients though I have other sources as well. I've been coding for over a year already. I have experience with building websites, mobile apps, Python-based apps as well as JS-based apps and even web-games and little bit of framework programming.</p>
      <br/>
      <h3 className='text-warning bg-dark'>Contact him on his socials</h3>
      <a href='#' className='text-decoration-none text-secondary'>Website</a> <br/>
      <a href='#' className='text-decoration-none text-danger'>Quora</a> <br/>
      <a href='#' className='text-decoration-none text-primary'>LinkedIn</a> <br/>
      <a href='#' className='text-decoration-none text-warning-emphasis'>Replit</a> <br/>
      <a href='#' className='text-decoration-none text-dark'>GitHub</a> <br/>
      <a href='#' className='text-decoration-none text-danger-emphasis'>Stack Overflow</a> <br/>
      <a href='#' className='text-decoration-none text-primary-emphasis'>Steam</a> <br/>
      <a href='#' className='text-decoration-none text-success'>Upwork</a> <br/>
      <br/>
    </div>
  )
}
