import React from 'react'

export default function AbtHead() {
  return (
    <div>
      <h2 className='text-success'>Who is Saptarshi Paul/Vastav?</h2>
    </div>
  )
}
