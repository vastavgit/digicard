import React from 'react'

export default function AbtImg() {
  return (
    <div>
      <img src='./profile.jpg' alt='Profile picture'></img>
    </div>
  )
}
