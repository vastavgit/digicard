import React from 'react'

export default function AbtPara() {
  return (
    <div>
      <p className='text-danger'>Hi, I am Saptarshi Paul aka Vastav, an Indian software developer, hailing from the city of Kolkata, WB, India. I have always been passionate towards programming and at the age of 16, I managed to learn those basics which gave me a kickstart in coding. I'm a Web Developer, Android Developer, React Developer, Python Developer. I have quite a significant amount of skills in programming and cybersecurity too. While my family always criticised me for being a coder, I knew what was right for me and what was not. I'm a software developer at Upwork and use the platform to find my clients though I have other sources as well. I've been coding for over a year already. I have experience with building websites, mobile apps, Python-based apps as well as JS-based apps and even web-games and little bit of framework programming. </p>
    </div>
  )
}
